% linear transform function for contrast enhancement 
% (a,Ta) and (b,Tb) are fixed points
% I is a gray image, J the enhaced image 
function J=T(a,Ta,b,Tb,I)    
    L=256;
    I=double(I);    
    indA=find(I<=a);
    indAB=find(I>a & I<=b);
    indB=find(I>b);
    
    J=I;
    J(indA)=(Ta/a)*I(indA);
    J(indAB)=Ta+((Tb-Ta)/(b-a))*(I(indAB)-a);
    J(indB)=Tb+((L-1-Tb)/(L-1-b))*(I(indB)-b);
    J=uint8(J);
end