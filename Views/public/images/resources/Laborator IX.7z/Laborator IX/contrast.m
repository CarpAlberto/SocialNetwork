clear all;

%partLab=1; %image complement/negative
%partLab=2; %liniar contrast enhacement
%partLab=3; %logarithm transformation 
%partLab=4; %gamma correction

%partLab=5; %histogram equalization
%partLab=6; %color histogram equalization
%partLab=7; %histogram matching
partLab=8; %adaptive histogram equalization

switch partLab
    
    case 1       
        [I,map]=imread('spine.tif');
        I=ind2gray(I,map);
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(1,2,1);
        subimage(I);        
        subplot(1,2,2);
        subimage(255-I);
        pause
        I=imread('mammogram.png');
        subplot(1,2,1);
        subimage(I);
        subplot(1,2,2);
        subimage(255-I);
        
      
    case 2
        I=imread('lena512.bmp');     
        figure('units','normalized','outerposition',[0 0 1 1])
        
        subplot(2,3,1);
        imshow(I);
        title('Original');
        
        subplot(2,3,2);
        T1=30;alpha=30;
        T2=120;beta=220;
        J=T(T1,alpha,T2,beta,I);
        imshow(J);
        title('Contrast imbunatatit');
        
        subplot(2,3,3);
        T1=120;alpha=60;
        T2=200;beta=230;
        J=T(T1,alpha,T2,beta,I);
        imshow(J);
        title('Contrast imbunatatit');
        
        
        subplot(2,3,4);
        T1=20;alpha=70;
        T2=220;beta=170;
        J=T(T1,alpha,T2,beta,I);
        imshow(J);
        title('Contrast micsorat');
        
        subplot(2,3,5);
        T1=120;alpha=120;
        T2=240;beta=150;
        J=T(T1,alpha,T2,beta,I);       
        imshow(J);
        title('Contrast micsorat');
        
        
        subplot(2,3,6);
        h=imhist(I,256);
        H=0;
        for T1=1:256
            H=H+h(T1);
            if(H/(512*512)>0.025)
                break
            end
        end        
        H=0;
        for T2=256:-1:1
            H=H+h(T2);
            if(H/(512*512)>0.025)
                break
            end
        end 
        
        J=T(T1,0,T2,255,I);
        imshow(J);
        title('Contrast optim');  
        
        pause
        
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(1,3,1);
        imshow(I);
        title('Original');
        
        subplot(1,3,2);
        J=imadjust(I,[0 1],[0.25 0.75],1);
        imshow(J);
        title('Contrast redus');
        
        subplot(1,3,3);
        J=imadjust(I,[0.2 0.8],[0 1],1);
        imshow(J);
        title('Contrast marit');
        
     case 3         
        x=0:1:255;
        k=0.1;
        y1=255*log(1+k*x)/log(1+k*255);               
        y2=255*log(1+10*x)/log(1+10*255);
        y3=255*log(1+1000*x)/log(1+1000*255);
                     
        I=imread('tire.tif');        
        
        I2=double(I);
        J1=uint8(255*log(1+I2)/log(1+255));
        J2=uint8(255*log(1+I2*10)/log(1+255*10));
        J3=uint8(255*log(1+I2*1000)/log(1+255*1000));
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(2,4,1),imshow(I),title('Original');
        subplot(2,4,2), imhist(I);
        subplot(2,4,3),imshow(J1),title('Log(I)');        
        subplot(2,4,4), plot(y1), axis([0,255,0,255]);        
        subplot(2,4,5),imshow(J2),title('Log(10*I)');        
        subplot(2,4,6), plot(y2), axis([0,255,0,255]);
        subplot(2,4,7),imshow(J3),title('Log(1000*I)');
        subplot(2,4,8), plot(y3), axis([0,255,0,255]);  
                
        pause
        
        subplot(1,2,1),imshow(I),title('Original');        
        subplot(1,2,2),imshow(J2),title('Log(10*I)');        
        
    case 4    
        x=0:1:255;
        y1=255*((x/255).^2);               
        y2=255*((x/255).^0.5);
        
        I=imread('tire.tif');
        J1=imadjust(I,[],[],2);
        J2=imadjust(I,[],[],0.5);
        J3=imadjust(J2,[],[],2);
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(2,3,1),imshow(I),title('Original');
        subplot(2,3,2),imshow(J1),title('Gamma=2');
        subplot(2,3,3),plot(y1), title('Gamma=2'), axis([0,255,0,255]);     
        subplot(2,3,4),imshow(J2),title('Gamma=0.5');
        subplot(2,3,5),plot(y2), title('Gamma=0.5'), axis([0,255,0,255]);     
        subplot(2,3,6),imshow(J3),title('Gamma correction');
                                           
    case 5
        I=imread('lena512.bmp');
        [l,c]=size(I);
        h=imhist(I,256);
        h=double(h);
        h=h/(l*c);
        H=zeros(1,256);
        
        H(1)=h(1);
        for i=2:256
            H(i)=H(i-1)+h(i);
        end
        H=double(H);
        J=H(I)*255;
        J=uint8(J);
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(2,2,1);
        imshow(I)
        subplot(2,2,2);
        bar(imhist(I),'b');
        set(gca,'xlim',[0 255]);
        subplot(2,2,3);
        imshow(J)       
        subplot(2,2,4);
        bar(imhist(J),'r');
        set(gca,'xlim',[0 255]);  
               
        pause
        
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(1,2,1),imshow(I), title('Original');        
        subplot(1,2,2),imshow(J), title('Egalizare Histograma');
                               
      
    case 6
        RGBs={imread('peppers.png'),imread('lena512color.bmp')};        
        figure('units','normalized','outerposition',[0 0 1 1])
        for i=1:2
            RGB=RGBs{i};
            EqRGB=rgb2ycbcr(RGB);            
            for c=0:0.5:1                               
                J=EqRGB;
                % combinatie liniara intre 
                %imaginea contrastata si imaginea originala
                J(:,:,1)=c*double(histeq(EqRGB(:,:,1),256))+(1-c)*double(EqRGB(:,:,1));                              
                J=ycbcr2rgb(J);            
                subplot(2,3,(i-1)*3+c*2+1);
                imshow(J);
                msg=sprintf('Enhanced %d %%',c*100);
                title(msg);
            end          
        end
        
    case 7
        I=imread('moon.tif');
        [l,c]=size(I);
        X=[1:256];
        %pdf2 = log(X/256); %log transform
        %pdf2 = power(X/256,2); %power function
        %pdf2 = abs(sin(40*X/256*pi)); %sinus function
        %pdf2=pdf2/sum(pdf2);
              
        pdf1(X)=ones(1,256);
        pdf1=pdf1/sum(pdf1);
                         
        pdf2=ones(1,256);       
        N=10;
        Y=[1:2*N];
        pdf2(Y)=40*abs(cos((Y-N)/(2*N)*pi));
        pdf2=pdf2/sum(pdf2);
        
        
        J1=histeq(I,pdf1); 
        J2=histeq(I,pdf2);
        
        figure('units','normalized','outerposition',[0 0 1 1])
        subplot(2,3,1);
        imshow(I);
        subplot(2,3,2);
        imshow(J1);
        subplot(2,3,3);
        imshow(J2);
              
        subplot(2,3,4);
        bar(imhist(I),'b');
        set(gca,'xlim',[0 255]);
        hold on
        plot(pdf1*l*c,'r');
        plot(pdf2*l*c,'g');
                        
        hold off
        
        subplot(2,3,5);
        bar(imhist(J1),'r');
        set(gca,'xlim',[0 255]);
        
        subplot(2,3,6);
        bar(imhist(J2),'g');
        set(gca,'xlim',[0 255]);
        
        pause
        
        subplot(1,2,1);
        imshow(I);
        subplot(1,2,2);
        imshow(J2);        
        
    case 8
        
        I = imread('tire.tif');        
        J1 = histeq(I,256);
                
        fun = @(x) histeq(x,256);
        J2 = blkproc(I,[64 64],fun);
        
        J3 = adapthisteq(I);
        %figure('units','normalized','outerposition',[0 0 1 1])
        subplot(2,2,1);
        imshow(I);
        title('Original');
        subplot(2,2,2);
        imshow(J1);
        title('Histogram Equalization');
        subplot(2,2,3);
        imshow(J2);
        title('Block Histogram Equalization');
        subplot(2,2,4);
        imshow(J3);
        title('Adaptive Histogram Equalization');
        
end




